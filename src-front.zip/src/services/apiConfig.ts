// src/services/apiConfig.ts
export const API_BASE_URL = "http://localhost:9000"; // Puerto ajustado a 9000